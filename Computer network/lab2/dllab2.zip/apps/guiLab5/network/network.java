import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

import java.util.Vector;

public class network extends JFrame implements ActionListener, ChangeListener {

   public void stateChanged(ChangeEvent e)  {
     //ckeck what event
     if (e.getSource().equals(probSlider))
     {
       int value = probSlider.getValue();

       probLbl.setText("" + PROB_STR_PRE + value/10.0 + PROB_STR_POST);

       //Add all packats to send to output buffer...
       byte[] txData = new byte[21];

       txData[0] = 0x02;

       txData[1] = (byte)('0' +  value / 100);
       txData[2] = (byte)('0' + (value / 10) % 10);
       txData[3] = (byte)('0' +  value % 10);

       value = propSlider.getValue();
       txData[4] = (byte)('0' +  value / 100);
       txData[5] = (byte)('0' + (value / 10) % 10);
       txData[6] = (byte)('0' +  value % 10);

       value = txSlider.getValue();
       txData[7] = (byte)('0' +  value / 1000);
       txData[8] = (byte)('0' + (value / 100) & 10);
       txData[9] = (byte)('0' + (value / 10) % 10);
       txData[10] = (byte)('0' +  value % 10);

       value = queueSlider.getValue();
       txData[11] = (byte)('0' +  value / 100);
       txData[12] = (byte)('0' + (value / 10) % 10);
       txData[13] = (byte)('0' +  value % 10);

       value = leackySlider.getValue();
       txData[14] = (byte)('0' +  value / 1000);
       txData[15] = (byte)('0' + (value / 100) % 10);
       txData[16] = (byte)('0' + (value / 10) % 10);
       txData[17] = (byte)('0' +  value % 10);

       value = windowSlider.getValue();
       txData[18] = (byte)('0' +  value / 100);
       txData[19] = (byte)('0' + (value / 10) % 10);
       txData[20] = (byte)('0' +  value % 10);

       txTask.sendData(txData);

//     this.fireChange(PipeEvent.ERROR_PROB);
     }
     else if (e.getSource().equals(propSlider))
     {
       int value = propSlider.getValue();

       propLbl.setText("" + PROP_STR_PRE + value + PROP_STR_POST);

       //Add all packats to send to output buffer...
       byte[] txData = new byte[21];

       txData[0] = 0x02;

       txData[4] = (byte)('0' +  value / 100);
       txData[5] = (byte)('0' + (value / 10) % 10);
       txData[6] = (byte)('0' +  value % 10);

       value = probSlider.getValue();

       txData[1] = (byte)('0' +  value / 100);
       txData[2] = (byte)('0' + (value / 10) % 10);
       txData[3] = (byte)('0' +  value % 10);

       value = txSlider.getValue();

       txData[7] = (byte)('0' +  value / 1000);
       txData[8] = (byte)('0' + (value / 100) % 10);
       txData[9] = (byte)('0' + (value / 10) % 10);
       txData[10] = (byte)('0' +  value % 10);

       value = queueSlider.getValue();
       txData[11] = (byte)('0' +  value / 100);
       txData[12] = (byte)('0' + (value / 10) % 10);
       txData[13] = (byte)('0' +  value % 10);

       value = leackySlider.getValue();
       txData[14] = (byte)('0' +  value / 1000);
       txData[15] = (byte)('0' + (value / 100) % 10);
       txData[16] = (byte)('0' + (value / 10) % 10);
       txData[17] = (byte)('0' +  value % 10);

       value = windowSlider.getValue();
       txData[18] = (byte)('0' +  value / 100);
       txData[19] = (byte)('0' + (value / 10) % 10);
       txData[20] = (byte)('0' +  value % 10);

       txTask.sendData(txData);
     }

     else if (e.getSource().equals(txSlider))
     {
       int value = txSlider.getValue();

       txLbl.setText("" + TX_STR_PRE + value + TX_STR_POST);

       //Add all packats to send to output buffer...
       byte[] txData = new byte[21];

       txData[0] = 0x02;

       txData[7] = (byte)('0' +  value / 1000);
       txData[8] = (byte)('0' + (value / 100) % 10);
       txData[9] = (byte)('0' + (value / 10) % 10);
       txData[10] = (byte)('0' +  value % 10);

       value = probSlider.getValue();

       txData[1] = (byte)('0' +  value / 100);
       txData[2] = (byte)('0' + (value / 10) % 10);
       txData[3] = (byte)('0' +  value % 10);

       value = propSlider.getValue();

       txData[4] = (byte)('0' +  value / 100);
       txData[5] = (byte)('0' + (value / 10) % 10);
       txData[6] = (byte)('0' +  value % 10);

       value = queueSlider.getValue();
       txData[11] = (byte)('0' +  value / 100);
       txData[12] = (byte)('0' + (value / 10) % 10);
       txData[13] = (byte)('0' +  value % 10);

       value = leackySlider.getValue();
       txData[14] = (byte)('0' +  value / 1000);
       txData[15] = (byte)('0' + (value / 100) % 10);
       txData[16] = (byte)('0' + (value / 10) % 10);
       txData[17] = (byte)('0' +  value % 10);

       value = windowSlider.getValue();
       txData[18] = (byte)('0' +  value / 100);
       txData[19] = (byte)('0' + (value / 10) % 10);
       txData[20] = (byte)('0' +  value % 10);

       txTask.sendData(txData);
     }

     else if (e.getSource().equals(queueSlider))
     {
       int value = queueSlider.getValue();

       queueLbl.setText("" + QUEUE_STR_PRE + value + QUEUE_STR_POST);

       //Add all packats to send to output buffer...
       byte[] txData = new byte[21];

       txData[0] = 0x02;

       txData[11] = (byte)('0' +  value / 100);
       txData[12] = (byte)('0' + (value / 10) % 10);
       txData[13] = (byte)('0' +  value % 10);

       value = probSlider.getValue();

       txData[1] = (byte)('0' +  value / 100);
       txData[2] = (byte)('0' + (value / 10) % 10);
       txData[3] = (byte)('0' +  value % 10);

       value = propSlider.getValue();

       txData[4] = (byte)('0' +  value / 100);
       txData[5] = (byte)('0' + (value / 10) % 10);
       txData[6] = (byte)('0' +  value % 10);

       value = txSlider.getValue();
       txData[7] = (byte)('0' +  value / 1000);
       txData[8] = (byte)('0' + (value / 100) % 10);
       txData[9] = (byte)('0' + (value / 10) % 10);
       txData[10] = (byte)('0' +  value % 10);

       value = leackySlider.getValue();
       txData[14] = (byte)('0' +  value / 1000);
       txData[15] = (byte)('0' + (value / 100) % 10);
       txData[16] = (byte)('0' + (value / 10) % 10);
       txData[17] = (byte)('0' +  value % 10);

       value = windowSlider.getValue();
       txData[18] = (byte)('0' +  value / 100);
       txData[19] = (byte)('0' + (value / 10) % 10);
       txData[20] = (byte)('0' +  value % 10);

       txTask.sendData(txData);
     }

     else if (e.getSource().equals(leackySlider))
     {
       int value = leackySlider.getValue();

       leackyLbl.setText("" + LEACKY_STR_PRE + value + LEACKY_STR_POST);

       //Add all packats to send to output buffer...
       byte[] txData = new byte[21];

       txData[0] = 0x02;

       txData[14] = (byte)('0' +  value / 1000);
       txData[15] = (byte)('0' + (value / 100) % 10);
       txData[16] = (byte)('0' + (value / 10) % 10);
       txData[17] = (byte)('0' +  value % 10);

       value = probSlider.getValue();

       txData[1] = (byte)('0' +  value / 100);
       txData[2] = (byte)('0' + (value / 10) % 10);
       txData[3] = (byte)('0' +  value % 10);

       value = propSlider.getValue();

       txData[4] = (byte)('0' +  value / 100);
       txData[5] = (byte)('0' + (value / 10) % 10);
       txData[6] = (byte)('0' +  value % 10);

       value = queueSlider.getValue();
       txData[11] = (byte)('0' +  value / 100);
       txData[12] = (byte)('0' + (value / 10) % 10);
       txData[13] = (byte)('0' +  value % 10);

       value = txSlider.getValue();
       txData[7] = (byte)('0' +  value / 1000);
       txData[8] = (byte)('0' + (value / 100) % 10);
       txData[9] = (byte)('0' + (value / 10) % 10);
       txData[10] = (byte)('0' +  value % 10);

       value = windowSlider.getValue();
       txData[18] = (byte)('0' +  value / 100);
       txData[19] = (byte)('0' + (value / 10) % 10);
       txData[20] = (byte)('0' +  value % 10);

       txTask.sendData(txData);
     }

     else if (e.getSource().equals(windowSlider))
     {
       int value = windowSlider.getValue();

       windowLbl.setText("" + WINDOW_STR_PRE + value + WINDOW_STR_POST);

       //Add all packats to send to output buffer...
       byte[] txData = new byte[21];

       txData[0] = 0x02;

       txData[18] = (byte)('0' +  value / 100);
       txData[19] = (byte)('0' + (value / 10) % 10);
       txData[20] = (byte)('0' +  value % 10);

       value = probSlider.getValue();

       txData[1] = (byte)('0' +  value / 100);
       txData[2] = (byte)('0' + (value / 10) % 10);
       txData[3] = (byte)('0' +  value % 10);

       value = propSlider.getValue();

       txData[4] = (byte)('0' +  value / 100);
       txData[5] = (byte)('0' + (value / 10) % 10);
       txData[6] = (byte)('0' +  value % 10);

       value = txSlider.getValue();
       txData[7] = (byte)('0' +  value / 1000);
       txData[8] = (byte)('0' + (value / 100) % 10);
       txData[9] = (byte)('0' + (value / 10) % 10);
       txData[10] = (byte)('0' +  value % 10);

       value = queueSlider.getValue();
       txData[11] = (byte)('0' +  value / 100);
       txData[12] = (byte)('0' + (value / 10) % 10);
       txData[13] = (byte)('0' +  value % 10);

       value = leackySlider.getValue();
       txData[14] = (byte)('0' +  value / 1000);
       txData[15] = (byte)('0' + (value / 100) % 10);
       txData[16] = (byte)('0' + (value / 10) % 10);
       txData[17] = (byte)('0' +  value % 10);

       txTask.sendData(txData);
     }
   }


  public void actionPerformed(ActionEvent e) {
     if (e.getActionCommand().equals("Reset Text Area For Node #0")) {
       textAreaWest.setText("");
     }

     if (e.getActionCommand().equals("Reset Text Area For Node #1")) {
       textAreaEast.setText("");
     }

/*
     else if (e.getActionCommand().equals("Send")) {
       String outData = inputArea.getText();
       
       if(outData != null && outData.trim().length() > 0) {
         txTask.sendData(outData.getBytes());
       }

       String blSize = blSizeField.getText();
       if(blSize != null && blSize.trim().length() > 0) {
         try {
           blockSize = Integer.parseInt(blSize);
         }catch(NumberFormatException bfe) {
         }
       }
     }

     else if(e.getActionCommand().equals("Send 00-99"))
     {
       System.out.println("\nStarts sending 00-99...");

       //Parse block length...
       String blSize = blSizeField.getText();
       if(blSize != null && blSize.trim().length() > 0)
       {
         try
         {
           blockSize = Integer.parseInt(blSize);
           if (blockSize < 3)
             blockSize = 5;
         } catch(NumberFormatException bfe)
         {
         }
       }

       //Add all packats to send to output buffer...
       byte[] txData = new byte[blockSize*100];
       int j;
       
       for (int i = 0; i < 100; i++)
       {
         txData[i*blockSize]   = (byte)('0' + i / 10);
         txData[i*blockSize+1] = (byte)('0' + i % 10);
         txData[i*blockSize+2] = (byte)' ';
         for(j = 3; j < blockSize-1; j++)
           txData[i*blockSize+j] = (byte)('a' + j - 3);
         txData[i*blockSize+j] = (byte)'\n';
       }

       txTask.sendData(txData);
     }
     else if(e.getActionCommand().equals("Reset")) {
//       numPkt = 0;
//       pktLbl.setText(PKT_STR+"     "+numPkt);
     }
*/

  }


  public network(int port, String name, String lab5, int queueSizeInit, int leackySpeedInit, int windowSizeInit)
  {

    this.serverPort      = port;
    this.name            = name;
    this.lab5a           = lab5.equals("lab5a");
    this.queueSizeInit   = queueSizeInit;
    this.leackySpeedInit = leackySpeedInit;
    this.windowSizeInit  = windowSizeInit;

    JPanel back = new JPanel(new BorderLayout());

    // ---initial layout setup
    JPanel panelWest  = new JPanel(new BorderLayout());
    JPanel panelSouth = new JPanel(new BorderLayout());
    JPanel panelEast  = new JPanel(new BorderLayout());
    back.add(panelWest,  BorderLayout.WEST);
    back.add(panelSouth, BorderLayout.SOUTH);
    back.add(panelEast,  BorderLayout.EAST);


    // --- west side - text area ---
    JPanel westTopPnl = new JPanel(new FlowLayout());
    JLabel westLabel = new JLabel("Node #0");
    westTopPnl.add(westLabel);

    JPanel textAreaPnlWest = new JPanel();
    textAreaWest = new JTextArea(20, 80);
    textAreaWest.setFont(new Font("Courier", Font.PLAIN, 10));
    scrollPaneWest = new JScrollPane(textAreaWest);
    scrollPaneWest.setAutoscrolls(true);
    textAreaPnlWest.add(scrollPaneWest);

    JButton resetBtnWest = new JButton("Reset Text Area For Node #0");
    resetBtnWest.addActionListener(this);
    westTopPnl.add(resetBtnWest);

    panelWest.add(westTopPnl,      BorderLayout.NORTH);
    panelWest.add(textAreaPnlWest, BorderLayout.CENTER);



    // --- east side - text area ---
    JPanel eastTopPnl = new JPanel(new FlowLayout());
    JLabel eastLabel = new JLabel("Node #1");
    eastTopPnl.add(eastLabel);

    JPanel textAreaPnlEast = new JPanel();
    textAreaEast = new JTextArea(20, 80);
    textAreaEast.setFont(new Font("Courier", Font.PLAIN, 10));
    scrollPaneEast = new JScrollPane(textAreaEast);
    scrollPaneEast.setAutoscrolls(true);
    textAreaPnlEast.add(scrollPaneEast);

    JButton resetBtnEast = new JButton("Reset Text Area For Node #1");
    resetBtnEast.addActionListener(this);
    eastTopPnl.add(resetBtnEast);

    panelEast.add(eastTopPnl,    BorderLayout.NORTH);
    panelEast.add(textAreaPnlEast, BorderLayout.CENTER);



    // --- center - communication channel sliders ---
    JPanel portLblPnl = new JPanel(new FlowLayout());
    pipe = new PipePanel();
    portLblPnl.add(pipe);
//    panelSouth.add(portLblPnl, BorderLayout.NORTH);

    //Slider panel
    JPanel sliderPnl  = new JPanel(new GridLayout(3,2));
//    JPanel slider2Pnl = new JPanel(new GridLayout(2,2));
//    sliderPnl.add(slider2Pnl, BorderLayout.CENTER);
    panelSouth.add(sliderPnl, BorderLayout.SOUTH);

    //Probability slider...
    JPanel probSliderPnl = new JPanel(new BorderLayout());
    probSlider = new JSlider(0, 100, 0);
    probSlider.addChangeListener(this);
    probSliderPnl.add(probSlider, BorderLayout.CENTER);

    probLbl = new JLabel(PROB_STR_PRE + probSlider.getValue()/10.0 + PROB_STR_POST);
    JPanel probLblPnl = new JPanel();
    probLblPnl.add(probLbl);
    probSliderPnl.add(probLblPnl, BorderLayout.SOUTH);
//
    sliderPnl.add(probSliderPnl);

    //Window size slider...
    JPanel windowSliderPnl = new JPanel(new BorderLayout());
    windowSlider = new JSlider(1, 64, 1);
    windowSlider.addChangeListener(this);
    windowSliderPnl.add(windowSlider, BorderLayout.CENTER);

    windowLbl = new JLabel(WINDOW_STR_PRE + windowSlider.getValue() + WINDOW_STR_POST);
    JPanel windowLblPnl = new JPanel();
    windowLblPnl.add(windowLbl);
    windowSliderPnl.add(windowLblPnl, BorderLayout.SOUTH);
//
    sliderPnl.add(windowSliderPnl);

    //Propagation (Tp) slider...
    JPanel propSliderPnl = new JPanel(new BorderLayout());
    propSlider = new JSlider(1, 100, 10);
    propSlider.addChangeListener(this);
    propSliderPnl.add(propSlider, BorderLayout.CENTER);

    propLbl = new JLabel(PROP_STR_PRE + propSlider.getValue() + PROP_STR_POST);
    JPanel propLblPnl = new JPanel();
    propLblPnl.add(propLbl);
    propSliderPnl.add(propLblPnl, BorderLayout.SOUTH);

    sliderPnl.add(propSliderPnl);

    //Tx slider...
    JPanel txSliderPnl = new JPanel(new BorderLayout());
    txSlider = new JSlider(10, 1000, 100);
    txSlider.addChangeListener(this);
    txSliderPnl.add(txSlider, BorderLayout.CENTER);

    txLbl = new JLabel(TX_STR_PRE + txSlider.getValue() + TX_STR_POST);
    JPanel txLblPnl = new JPanel();
    txLblPnl.add(txLbl);
    txSliderPnl.add(txLblPnl, BorderLayout.SOUTH);

    sliderPnl.add(txSliderPnl);

    //Queue slider...
    JPanel queueSliderPnl = new JPanel(new BorderLayout());
    if (queueSizeInit > 100 || queueSizeInit < 1)
      queueSizeInit = 1;
    queueSlider = new JSlider(1, 100, queueSizeInit);
    queueSlider.addChangeListener(this);

    queueSliderPnl.add(queueSlider, BorderLayout.CENTER);

    queueLbl = new JLabel(QUEUE_STR_PRE + queueSlider.getValue() + QUEUE_STR_POST);
    JPanel queueLblPnl = new JPanel();
    queueLblPnl.add(queueLbl);
    queueSliderPnl.add(queueLblPnl, BorderLayout.SOUTH);

    //Leacky slider...
    JPanel leackySliderPnl = new JPanel(new BorderLayout());
    if(leackySpeedInit > 1000 || leackySpeedInit < 1)
      leackySpeedInit = 1000;
    leackySlider = new JSlider(1, 1000, leackySpeedInit);
    leackySlider.addChangeListener(this);
    leackySliderPnl.add(leackySlider, BorderLayout.CENTER);

    leackyLbl = new JLabel(LEACKY_STR_PRE + leackySlider.getValue() + LEACKY_STR_POST);
    JPanel leackyLblPnl = new JPanel();
    leackyLblPnl.add(leackyLbl);
    leackySliderPnl.add(leackyLblPnl, BorderLayout.SOUTH);

if (lab5a == false)
{
    sliderPnl.add(queueSliderPnl);
    sliderPnl.add(leackySliderPnl);
}

/*

    // --- east side ---
    JPanel east = new JPanel(new BorderLayout());

    // block size
    JPanel blSizePnl = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JLabel blSizeLbl = new JLabel("Block size: ");
    blSizeField      = new JTextField(5); 
    blSizeField.setText(""+blockSize);

    blSizePnl.add(blSizeLbl);
    blSizePnl.add(blSizeField);

    east.add(blSizePnl, BorderLayout.NORTH);

    // input area
    JPanel inpPnl = new JPanel();
    JPanel inputAreaPnl = new JPanel(new BorderLayout());

    inputArea = new JTextArea(3,20);
    inputArea.setLineWrap(true);
    inpPnl.add(new JScrollPane(inputArea));
    inputAreaPnl.add(inpPnl, BorderLayout.CENTER);

    east.add(inputAreaPnl, BorderLayout.CENTER);

    // send buttons
    JPanel sendBtnPnl = new JPanel();
    JButton sendBtn = new JButton("Send");
    sendBtn.addActionListener(this);
    sendBtnPnl.add(sendBtn);
    
    JButton send999Btn = new JButton("Send 00-99");
    send999Btn.addActionListener(this);
    sendBtnPnl.add(send999Btn);

    inputAreaPnl.add(sendBtnPnl, BorderLayout.SOUTH);


    // info
    JPanel infoPnl = new JPanel();
    pktLbl  = new JLabel(PKT_STR+"     0");
    JButton resetBtn = new JButton("Reset");
    resetBtn.addActionListener(this);

    infoPnl.add(pktLbl);
    infoPnl.add(resetBtn);
    east.add(infoPnl, BorderLayout.SOUTH);

    back.add(east, BorderLayout.EAST);
*/

//KEEP
    this.getContentPane().add(back);
    this.setTitle(name);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(1024, 520);
//    this.pack();
//    this.setLocation(xPos,yPos);
    this.setVisible(true);


    // start threads
    new Thread(new RxTask()).start();
    txTask = new TxTask();
    new Thread(txTask).start();
  }


  class RxTask implements Runnable {
    private Vector WestData2Send = new Vector();
    private Vector EastData2Send = new Vector();

    public synchronized byte[] getWestData()
    {
      byte[] ret = null; 

      try
      {
        while (WestData2Send.size() == 0)
          wait();

        ret = (byte[]) WestData2Send.elementAt(0);
        WestData2Send.removeElementAt(0);
      }
      catch (InterruptedException ie)
      {
        System.out.println("getData: "+ie.getMessage());
      }
      return ret;
    }

    public synchronized void postWestData(byte[] rxData, int rxCount)
    {
      byte[] messageToSend = new byte[rxCount-2];
      System.arraycopy(rxData, 2, messageToSend, 0, rxCount-2);
      WestData2Send.add(messageToSend);
      notifyAll();
    }

    public synchronized byte[] getEastData()
    {
      byte[] ret = null; 

      try
      {
        while (EastData2Send.size() == 0)
          wait();

        ret = (byte[]) EastData2Send.elementAt(0);
        EastData2Send.removeElementAt(0);
      }
      catch (InterruptedException ie)
      {
        System.out.println("getData: "+ie.getMessage());
      }
      return ret;
    }

    public synchronized void postEastData(byte[] rxData, int rxCount)
    {
      byte[] messageToSend = new byte[rxCount-2];
      System.arraycopy(rxData, 2, messageToSend, 0, rxCount-2);
      EastData2Send.add(messageToSend);
      notifyAll();
    }

    public void run() {
      int ch;
      int i;
      char[]       WestRingBuffer         = new char[RING_BUFFER_SIZE];
      StringBuffer WestRingBufferTextArea = new StringBuffer(RING_BUFFER_SIZE);
      int          WestRingBufferRear     = 0;
      boolean      WestRingBufferFull     = false;

 
      char[]       EastRingBuffer         = new char[RING_BUFFER_SIZE];
      StringBuffer EastRingBufferTextArea = new StringBuffer(RING_BUFFER_SIZE);
      int          EastRingBufferRear     = 0;
      boolean      EastRingBufferFull     = false;

      try {
        server = new ServerSocket(serverPort);
      }
      catch (IOException ie) {
        System.out.println("RxTask.run(): "+ie.getMessage());
        return;
      }

      while (true) {
        try {

          // wait for a connection
          Socket sock = server.accept();

          // get streams from socket
          sockInput  = sock.getInputStream();
          sockOutput = sock.getOutputStream();

          closed = false;
          pipe.leftConnected();
          pipe.rightConnected();

          // read data from socket and forward to other end
          while (!closed) {
            ch = sockInput.read();

            //Check if connection is broken...
            if (ch == -1)
              throw new IOException();

            //State machine to decrypt frames...
            if (rxState == 0 && (byte)ch == DLE)
              rxState = 1;

            else if (rxState == 1 && (byte)ch == STX)
            {
              rxCount = 0;    //reset buffer
              rxState = 2;
            }
            else if (rxState == 1 && (byte)ch == DLE)
              rxState = 1;
            else if (rxState == 1)
              rxState = 0;

            else if (rxState == 2 && (byte)ch == DLE)
              rxState = 3;
            else if (rxState == 2)
            {
              //add to buffer
              rxData[rxCount] = (byte)ch;
              rxCount++;
            }

            else if (rxState == 3 && (byte)ch == DLE)
            {
              //add to buffer
              rxData[rxCount] = (byte)ch;
              rxCount++;
            }
            else if (rxState == 3 && (byte)ch == STX)
            {
              rxCount = 0;  //reset buffer
              rxState = 2;
            }
            else if (rxState == 3 && (byte)ch == ETX)
            {
              //
              //EVALUATE RECEIVED FRAME
              //

              //check if "printf" frame
              if (rxData[0] == PRINTF_FRAME && rxCount > 2)
              {
//System.out.print("Rx2: received: " + newStr.substring(2,rxCount));

                //check if left node
                if (rxData[1] == LEFT_NODE)
                {
/*                	
                  for(i=2; i<rxCount; i++)
                  {
                    WestRingBuffer[WestRingBufferRear] = (char)rxData[i];
                    WestRingBufferRear = (WestRingBufferRear + 1) % RING_BUFFER_SIZE;
                    if (WestRingBufferRear == 0)
                      WestRingBufferFull = true;
                  }                  //construct text area string

                  //check if ring buffer is full
                  if (WestRingBufferFull == true)
                  {
                    for(i=0; i<RING_BUFFER_SIZE; i++)
                    {
                      WestRingBufferTextArea.setCharAt(i, WestRingBuffer[(WestRingBufferRear + i) % RING_BUFFER_SIZE]);
                    }
                  }

                  //ringbuffer is not full
                  else
                  {
                    String newStr = new String(rxData);
                    WestRingBufferTextArea.append((String)newStr.substring(2,rxCount));
                  }
                  textAreaWest.setText(new String(WestRingBufferTextArea));
*/

                  //append data to output text area
                  postWestData(rxData,rxCount);

                  Runnable updateAComponent = new Runnable()
                  {
                     public void run()
                     {
                       textAreaWest.append(new String(getWestData()));
                     }
                  };
                  SwingUtilities.invokeLater(updateAComponent);
                }

                //check if right node
                else if (rxData[1] == RIGHT_NODE)
                {
                  //append data to output text area
                  postEastData(rxData,rxCount);

                  Runnable updateAComponent = new Runnable()
                  {
                     public void run()
                     {
                       textAreaEast.append(new String(getEastData()));
                     }
                  };
                  SwingUtilities.invokeLater(updateAComponent);
               } 
             }

              //check if "communication indication" frame
              else if (rxData[0] == COMM_FRAME && rxCount == 2)
              {
                //check if left node
                if (rxData[1] == LEFT_NODE)
                  pipe.leftData();

                //check if right node
                else if (rxData[1] == RIGHT_NODE)
                  pipe.rightData();
              }

              else
                System.out.print("Rx: received unknown frame (type: " + rxData[0] + ", length: " + rxCount + ")");

              rxState = 0;
            }
            else if (rxState == 3)
              rxState = 0;
          }

        }
        catch (IOException ioe) {
          closed = true;
          pipe.leftDisconnected();
          pipe.rightDisconnected();
        }
      }
    }
  } // end RxTask

  class TxTask implements Runnable {

    public void run() {
      byte[] data = null;
      while (true) {

        System.out.print("Tx: wait for data to transmit...");
        data = getData();

        try
        {
          if (!closed && data != null)
          {
            for (int i = 0; i < data.length; i++)
              sockOutput.write(data[i]);

            System.out.println(" Sent frame of type: " + data[2]);
          }

          else if (data == null)
            System.out.println(" Nothing in frame to send...");

          else if (closed)
            System.out.println(" Got no connection... throw data away...");

        }
        catch (IOException ioe) {
          System.out.println("TxTask.run(): "+ioe.getMessage());
        }
      }
    }

    public synchronized void sendData(byte[] data)
    {
      byte[] messageToSend = new byte[4 + 2*data.length];
      int i = 0;

      //create frame to send...
      messageToSend[i++] = DLE;
      messageToSend[i++] = STX;

      for (int j = 0; j < data.length; j++)
      {
        //put together frames...
        messageToSend[i++] = data[j];
        if (data[j] == DLE)
          messageToSend[i++] = DLE;
      }

      //Stop frame
      messageToSend[i++] = DLE;
      messageToSend[i++] = ETX;

      data2Send.add(messageToSend);
      notifyAll();
    }

    public synchronized byte[] getData()
    {
      byte[] ret = null; 

      try {

        while (data2Send.size() == 0)
          wait();

        ret = (byte[]) data2Send.elementAt(0);
        data2Send.removeElementAt(0);

      }
      catch (InterruptedException ie) {
        System.out.println("getData: "+ie.getMessage());
      }

      return ret;

    }

    private Vector data2Send = new Vector();
  } // End TxTask

  public static void main(String[] args) {
    if (args.length != 6)
    {
      System.out.println("Usage: java network 'port number' \"name\" lab5a|lab5b queueSize leackSpeed windowSize");
      return;
    }
    network n = new network(Integer.parseInt(args[0]),args[1],args[2],Integer.parseInt(args[3]),Integer.parseInt(args[4]),Integer.parseInt(args[5]));
  }

  private JTextArea textAreaWest;
  private JScrollPane scrollPaneWest;
  private JTextArea textAreaEast;
  private JScrollPane scrollPaneEast;
  private PipePanel pipe;
  private JSlider probSlider;
  private JSlider propSlider;
  private JSlider txSlider;
  private JSlider queueSlider;
  private JSlider leackySlider;
  private JSlider windowSlider;

//  private Vector listeners = new Vector();
  private JLabel portLbl;
  private JLabel probLbl;
  private JLabel propLbl;
  private JLabel txLbl;
  private JLabel queueLbl;
  private JLabel leackyLbl;
  private JLabel windowLbl;
  private final String PORT_STR      = "Server port: ";
  private final String PROB_STR_PRE  = "Frame error probability: ";
  private final String PROB_STR_POST = " %";
  private final String PROP_STR_PRE  = "Propagation delay (Tp): ";
  private final String PROP_STR_POST = " ms";
  private final String TX_STR_PRE  = "Bit speed: ";
  private final String TX_STR_POST = " kbps";
  private final String QUEUE_STR_PRE  = "Queue size: ";
  private final String QUEUE_STR_POST = " entries";
  private final String LEACKY_STR_PRE  = "Leacky bucket speed: ";
  private final String LEACKY_STR_POST = " kbps";
  private final String WINDOW_STR_PRE  = "Sliding window size: ";
  private final String WINDOW_STR_POST = " frame(s)";

  private volatile boolean closed = true;

  private boolean lab5a;
  private int serverPort = 1042;
  private String name;
  private int queueSizeInit   = 1;
  private int leackySpeedInit = 10;
  private int windowSizeInit  = 1;

  private InputStream  sockInput;
  private OutputStream sockOutput;
  private ServerSocket server;

  private TxTask txTask;

  private byte DLE = 0x04;
  private byte STX = 0x02;
  private byte ETX = 0x03;
  private byte PRINTF_FRAME = 0x00;
  private byte COMM_FRAME   = 0x01;
  private byte LEFT_NODE    = 0x00;
  private byte RIGHT_NODE   = 0x01;

  private byte rxState = 0;
  private byte rxCount = 0;
  private byte[] rxData = new byte[1024];

  private int RING_BUFFER_SIZE = 10000;
}
