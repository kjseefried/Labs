/************************************************************************************************
* File:       fsm.h
* Programmer: Anders Rosvall
* Revision:   2003-01-24
************************************************************************************************/

typedef enum
{
  FSM_FALSE,
  FSM_TRUE
} fsmReturnType;

typedef enum
{
  STATE,
  EVENT,
  OPERATION,
  TABLE_END
} typeType;

typedef struct
{
  typeType type;
  long     number;
  char    *pMessage;
} messageType;

typedef struct
{
  int state;
  int inpEvent;
  int nextStateTrue;
  int nextStateFalse;
  fsmReturnType (*operation)(void);   //function pointer, taking no parameter, returning TRUE or FALSE
} stateTableType;

typedef struct
{
  stateTableType *stateTable;
  unsigned int    stateTableLength;
  int             state;
  messageType    *pMessages;
  long long       dbg_modes;
} fsmType;

