import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Color;
import java.awt.Font;
import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.awt.geom.RoundRectangle2D.Double;

public class PipePanel extends JPanel {


   public PipePanel() {
//   public PipePanel(int leftPort, int rightPort) {
//      this.leftPort = leftPort;
//      this.rightPort = rightPort;

      pWidth     = (MARGIN+CIRC_RD*2)*2 + CONN_LEN - CIRC_RD;
      pHeight    = CIRC_RD*2+2*MARGIN;
      connStartX = MARGIN+CIRC_RD+CIRC_RD/2;
      topConnY   = pHeight/2 - 1 - CIRC_RD/2;
      botConnY   = pHeight/2 - 1 + CIRC_RD/2;
   }

   public void paint(Graphics g) {
      Graphics2D g2 = (Graphics2D)g;

      Image backImage = createImage(pWidth, pHeight);

      Graphics2D g2i = (Graphics2D)backImage.getGraphics();

      g2i.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                           RenderingHints.VALUE_ANTIALIAS_ON);
      g2i.setRenderingHint(RenderingHints.KEY_RENDERING,
                           RenderingHints.VALUE_RENDER_QUALITY);


      drawPipe(g2i);  

      g2.drawImage(backImage, 0, 0,  this);
   }

   public Dimension getPreferredSize() {
      return new Dimension(pWidth, pHeight);
   }


   public void leftConnected() {
      leftConnected = true;
      repaint();
   }

   public void rightConnected() {
      rightConnected = true;
      repaint();
   }

   public void leftDisconnected() {
      leftConnected = false;
      repaint();
   }

   public void rightDisconnected() {
      rightConnected = false;
      repaint();
   }

   public void leftData() {
      leftData = true;
      repaint();
   }

   public void rightData() {
      rightData = true;
      repaint();
   }


   private void drawPipe(Graphics2D g2) {
      g2.setColor(Color.blue);

/*
      // top
      g2.drawLine(0, 0, pWidth-1, 0);
      // right
      g2.drawLine(pWidth-1, 0, pWidth-1, pHeight-1);
      // bottom
      g2.drawLine(pWidth-1, pHeight-1, 0, pHeight-1);
      //left
      g2.drawLine(0, pHeight-1, 0, 0);

      //middle vert
      g2.drawLine(pWidth/2 - 1, 0, pWidth/2 - 1, pHeight-1);

      //middle horiz
      g2.drawLine(0, pHeight/2 - 1, pWidth-1, pHeight/2 - 1);
*/

      drawTopConn(g2);
      drawBotConn(g2);

      drawLeftServer(g2);
      drawRightServer(g2);
   }

   private void drawTopConn(Graphics2D g2) {

      if(leftData) {
         g2.setColor(FLASH);
         g2.setStroke(bold);
         
         leftData = false;
         repaint();
      }
      else {
         g2.setColor(Color.black);
         g2.setStroke(solid);
      }


      // top connection
      g2.drawLine(connStartX, topConnY, connStartX+CONN_LEN, topConnY);

      // right arrow
      g2.drawLine(pWidth/2-1-5, topConnY-4, pWidth/2-1, topConnY);
      g2.drawLine(pWidth/2-1-5, topConnY+4, pWidth/2-1, topConnY);

   }

   private void drawBotConn(Graphics2D g2) {

      if(rightData) {
         g2.setColor(FLASH);
         g2.setStroke(bold);

         rightData = false;
         repaint();
      }
      else {
         g2.setColor(Color.black);      
         g2.setStroke(solid);
      }

      // bottom connection
      g2.drawLine(connStartX, botConnY, connStartX+CONN_LEN, botConnY);

      // left arrow
      g2.drawLine(pWidth/2-1, botConnY, pWidth/2-1+5, botConnY-4);
      g2.drawLine(pWidth/2-1, botConnY, pWidth/2-1+5, botConnY+4);
   }


   private void drawLeftServer(Graphics2D g2) {
      g2.setColor(Color.lightGray);

      // left circle
      g2.fillOval(MARGIN, pHeight/2 - 1 - CIRC_RD, CIRC_RD*2, CIRC_RD*2);

      if(leftConnected)
         g2.setStroke(solid);
      else
         g2.setStroke(dashed);

      g2.setColor(Color.black);
      g2.drawOval(MARGIN, pHeight/2 - 1 - CIRC_RD, CIRC_RD*2, CIRC_RD*2);

      g2.setFont(g2.getFont().deriveFont(10f));

//      int off = 4;
//      if(leftPort >=10000)
//         off = 1;

//      g2.drawString(""+leftPort, MARGIN+off, pHeight/2-1+CIRC_RD+10);
   }

   private void drawRightServer(Graphics2D g2) {
      g2.setColor(Color.lightGray);

      // right circle
      g2.fillOval(pWidth-1-2*CIRC_RD-MARGIN, pHeight/2 - 1 - CIRC_RD, CIRC_RD*2, CIRC_RD*2);
      
      if(rightConnected)
         g2.setStroke(solid);
      else
         g2.setStroke(dashed);
      
      g2.setColor(Color.black);
      g2.drawOval(pWidth-1-2*CIRC_RD-MARGIN, pHeight/2 - 1 - CIRC_RD, CIRC_RD*2, CIRC_RD*2);

      g2.setFont(g2.getFont().deriveFont(10f));

//      int off = 4;
//      if(rightPort >=10000)
//         off = 1;

//      g2.drawString(""+rightPort, pWidth-1-2*CIRC_RD-MARGIN+off, pHeight/2-1+CIRC_RD+10);
   }



   private int pHeight;
   private int pWidth;
   private int connStartX;
   private int topConnY;
   private int botConnY;

   private boolean leftConnected  = false;
   private boolean rightConnected = false;
   private boolean leftData       = false;
   private boolean rightData      = false;

//   private int leftPort = 1111;
//   private int rightPort = 32323;


   private float[] dash = {5f};

   private BasicStroke dashed = 
   new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash, 0.0f);
   private BasicStroke solid = new BasicStroke(1.0f);
   private BasicStroke bold  = new BasicStroke(5.0f); 



   private final Color FLASH = Color.red;

   private final int CIRC_RD  = 15;
   private final int MARGIN   = 15;
   private final int CONN_LEN = 100;

}
