import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

import java.util.Vector;

public class node extends JFrame implements ActionListener {

  public void actionPerformed(ActionEvent e) {
     if (e.getActionCommand().equals("Send text")) {
       String outData = inputArea.getText();
       
       String blSize = blSizeField.getText();
       if(blSize != null && blSize.trim().length() > 0) {
         try {
           blockSize = Integer.parseInt(blSize);
           if (blockSize < 5)
             blockSize = 5;
           if (blockSize > 50)
             blockSize = 50;
         }catch(NumberFormatException bfe) {
         }
       }
       blSizeField.setText("" + blockSize);

       timeArray[0] = 0;
       timeArray[1] = 0;
       timeArray[2] = 0;
       timeArray[3] = 0;
       timeArray[4] = 0;
       timeArray[5] = 0;
       timeArray[6] = 0;
       timeLbl.setText(TIME_STR+" [00:00.000]");

       if(outData != null && outData.trim().length() > 0) {
         txTask.sendData(outData.getBytes());
       }
     }
     else if(e.getActionCommand().equals("Send 00-99"))
     {
       System.out.println("\nStarts sending 00-99...");

       //Parse block length...
       String blSize = blSizeField.getText();
       if(blSize != null && blSize.trim().length() > 0) {
         try {
           blockSize = Integer.parseInt(blSize);
           if (blockSize < 5)
             blockSize = 5;
           if (blockSize > 50)
             blockSize = 50;
         }catch(NumberFormatException bfe) {
         }
       }
       blSizeField.setText("" + blockSize);

       timeArray[0] = 0;
       timeArray[1] = 0;
       timeArray[2] = 0;
       timeArray[3] = 0;
       timeArray[4] = 0;
       timeArray[5] = 0;
       timeArray[6] = 0;
       timeLbl.setText(TIME_STR+" [00:00.000]");

       //Add all packats to send to output buffer...
       int j;
       byte[] txData = new byte[100*blockSize];

       for (int i = 0; i < 100; i++)
       {
         txData[i*blockSize + 0] = (byte)('0' + i / 10);
         txData[i*blockSize + 1] = (byte)('0' + i % 10);
         txData[i*blockSize + 2] = (byte)' ';
         for(j = 3; j < blockSize-1; j++)
           txData[i*blockSize + j] = (byte)('a' + j - 3);
         txData[i*blockSize + j] = (byte)'\n';
       }
       txTask.sendData(txData);
     }
     else if(e.getActionCommand().equals("Reset")) {
       textArea.setText("");
       
       numPkt = 0;
       pktLbl.setText(PKT_STR+"     "+numPkt+"   ");

       timeArray[0] = 0;
       timeArray[1] = 0;
       timeArray[2] = 0;
       timeArray[3] = 0;
       timeArray[4] = 0;
       timeArray[5] = 0;
       timeArray[6] = 0;
       timeLbl.setText(TIME_STR+" [00:00.000]");

       lostFrame[0] = 0;
       lostFrame[1] = 0;
       lostFrame[2] = 0;
       lostLbl.setText(QUEUE_STR+"0/0/0");

       txTask.sendSync();
     }
  }


  public node(int port, String name) {

    this.serverPort = port;


    JPanel back = new JPanel(new BorderLayout());

    // --- west side - text area ---
    JPanel textAreaPnl = new JPanel();
    textArea = new JTextArea(10, 22);
    textAreaScroll = new JScrollPane(textArea);
    textAreaScroll.setAutoscrolls(true);

    textAreaPnl.add(textAreaScroll);

    back.add(textAreaPnl, BorderLayout.CENTER);

    // --- east side ---
    JPanel east = new JPanel(new BorderLayout());

    // block size
    JPanel blSizePnl = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JLabel blSizeLbl = new JLabel("Block size (5-50): ");
    blSizeField      = new JTextField(5); 
    blSizeField.setText(""+blockSize);

    blSizePnl.add(blSizeLbl);
    blSizePnl.add(blSizeField);

    east.add(blSizePnl, BorderLayout.NORTH);

    // input area
    JPanel inpPnl = new JPanel();
    JPanel inputAreaPnl = new JPanel(new BorderLayout());

    inputArea = new JTextArea(4,22);
    inputArea.setLineWrap(true);
    inpPnl.add(new JScrollPane(inputArea));
    inputAreaPnl.add(inpPnl, BorderLayout.CENTER);

    east.add(inputAreaPnl, BorderLayout.CENTER);

    // send buttons
    JPanel sendBtnPnl = new JPanel();
    JButton sendBtn = new JButton("Send text");
    sendBtn.addActionListener(this);
    sendBtnPnl.add(sendBtn);
    
    JButton send999Btn = new JButton("Send 00-99");
    send999Btn.addActionListener(this);
    sendBtnPnl.add(send999Btn);

    inputAreaPnl.add(sendBtnPnl, BorderLayout.SOUTH);


    // info
    JPanel infoPnl = new JPanel(new BorderLayout());
    pktLbl  = new JLabel(PKT_STR+"     0   ");
    JButton resetBtn = new JButton("Reset");
    resetBtn.addActionListener(this);

    infoPnl.add(pktLbl,BorderLayout.WEST);
    infoPnl.add(resetBtn,BorderLayout.EAST);
    timeLbl  = new JLabel(TIME_STR+" [00:00.000]");
    lostLbl  = new JLabel(QUEUE_STR+"0/0/0");

    JPanel info2Pnl = new JPanel(new BorderLayout());
    info2Pnl.add(timeLbl,BorderLayout.WEST);
    info2Pnl.add(lostLbl,BorderLayout.EAST);

    east.add(infoPnl, BorderLayout.SOUTH);
    back.add(east, BorderLayout.EAST);
    back.add(info2Pnl, BorderLayout.SOUTH);

    timeArray[0] = 0;
    timeArray[1] = 0;
    timeArray[2] = 0;
    timeArray[3] = 0;
    timeArray[4] = 0;
    timeArray[5] = 0;
    timeArray[6] = 0;

    this.getContentPane().add(back);
    this.setTitle(name);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(512, 315);
    this.pack();
    this.setVisible(true);


    // start threads
    new Thread(new RxTask()).start();
    txTask = new TxTask();
    new Thread(txTask).start();
  }

  private void incLostFrame(int stub0, int stub1, int stub2) {
    lostFrame[0] += stub0;
    lostFrame[1] += stub1;
    lostFrame[2] += stub2;
    lostLbl.setText(QUEUE_STR+lostFrame[0]+"/"+lostFrame[1]+"/"+lostFrame[2]);
  }

  private void incNumPkt(int num) {
    numPkt+=num;
    pktLbl.setText(PKT_STR+numPkt+"   ");
  }

  private void setTime(int n1, int n2, int n3, int n4, int n5, int n6, int n7) {
    timeArray[6] = (byte)n7;
    timeArray[5] = (byte)n6;
    timeArray[4] = (byte)n5;
    timeArray[3] = (byte)n4;
    timeArray[2] = (byte)n3;
    timeArray[1] = (byte)n2;
    timeArray[0] = (byte)n1;
    timeLbl.setText(TIME_STR+"["+timeArray[0]+timeArray[1]+":"+timeArray[2]+timeArray[3]+"."+timeArray[4]+timeArray[5]+timeArray[6]+"]");
  }

  private void incTime(int n1, int n2, int n3, int n4, int n5, int n6, int n7) {
    timeArray[6] += n7;
    if (timeArray[6] >= 10)
    {
      timeArray[6] -= 10;
      timeArray[5]++;
    }
    timeArray[5] += n6;
    if (timeArray[5] >= 10)
    {
      timeArray[5] -= 10;
      timeArray[4]++;
    }
    timeArray[4] += n5;
    if (timeArray[4] >= 10)
    {
      timeArray[4] -= 10;
      timeArray[3]++;
    }
    timeArray[3] += n4;
    if (timeArray[3] >= 10)
    {
      timeArray[3] -= 10;
      timeArray[2]++;
    }
    timeArray[2] += n3;
    if (timeArray[2] >= 6)
    {
      timeArray[2] -= 6;
      timeArray[1]++;
    }
    timeArray[1] += n2;
    if (timeArray[1] >= 10)
    {
      timeArray[1] -= 10;
      timeArray[0]++;
    }
    timeArray[0] += n1;
    if (timeArray[0] >= 10)
      timeArray[0] -= 10;

//System.out.println("[" + timeArray[0] + timeArray[1] + timeArray[2] + timeArray[3] + timeArray[4] + timeArray[5] + timeArray[6] + "]");
       
    timeLbl.setText(TIME_STR+"["+timeArray[0]+timeArray[1]+":"+timeArray[2]+timeArray[3]+"."+timeArray[4]+timeArray[5]+timeArray[6]+"]");
  }



  class RxTask implements Runnable {

    private Vector Data2Receive = new Vector();

    public synchronized byte[] getData()
    {
      byte[] ret = null; 

      try
      {
        while (Data2Receive.size() == 0)
          wait();

        ret = (byte[]) Data2Receive.elementAt(0);
        Data2Receive.removeElementAt(0);
      }
      catch (InterruptedException ie)
      {
        System.out.println("getData: "+ie.getMessage());
      }
      return ret;
    }

    public synchronized void postData(byte[] rxData, int rxCount)
    {
      byte[] messageToReceive = new byte[rxCount-1];
      System.arraycopy(rxData, 1, messageToReceive, 0, rxCount-1);
      Data2Receive.add(messageToReceive);
      notifyAll();
    }

    public void run() {
      int ch;

      try {
        server = new ServerSocket(serverPort);
      }
      catch (IOException ie) {
        System.out.println("RxTask.run(): "+ie.getMessage());
        return;
      }

      while (true) {
        try {

          // wait for a connection
          Socket sock = server.accept();

          // get streams from socket
          sockInput  = sock.getInputStream();
          sockOutput = sock.getOutputStream();

          closed = false;

          // read data from socket and forward to other end
          while (!closed) {
            ch = sockInput.read();

            //Check if connection is broken...
            if (ch == -1)
              throw new IOException();

            //State machine to decrypt frames...
            if (rxState == 0 && (byte)ch == DLE)
              rxState = 1;

            else if (rxState == 1 && (byte)ch == STX)
            {
              rxCount = 0;    //reset buffer
//              System.out.print("Rx: reset buffer...");
              rxState = 2;
            }
            else if (rxState == 1 && (byte)ch == DLE)
              rxState = 1;
            else if (rxState == 1)
              rxState = 0;

            else if (rxState == 2 && (byte)ch == DLE)
              rxState = 3;
            else if (rxState == 2)
            {
              //add to buffer
//              System.out.print("Rx: add["+ ch +"] to buffer...");
              rxData[rxCount] = (byte)ch;
              rxCount++;
            }

            else if (rxState == 3 && (byte)ch == DLE)
            {
              //add to buffer
//              System.out.print("Rx: add["+ ch +"] to buffer...");
              rxData[rxCount] = (byte)ch;
              rxCount++;
            }
            else if (rxState == 3 && (byte)ch == STX)
            {
              rxCount = 0;  //reset buffer
//              System.out.print("Rx: reset buffer...");
              rxState = 2;
            }
            else if (rxState == 3 && (byte)ch == ETX)
            {
              //evaluate buffer
//              System.out.print("Rx: evaluate buffer (len: " + rxData.length + ", " + rxCount + " ), [0]= " + rxData[0] + ";");

              //check if data frame
              if (rxData[0] == 0x00)
              {
                incNumPkt(1);
//                for (int i = 1; i < rxCount; i++)
//                  textArea.append(""+(char)rxData[i]);
                postData(rxData,rxCount);

                Runnable updateAComponent = new Runnable()
                {
                   public void run()
                   {
                     textArea.append(new String(getData()));
                   }
                };
                SwingUtilities.invokeLater(updateAComponent);
              }

              //check if ack frame
              else if (rxData[0] == 0x01 && rxCount == 10)
              {
//                incTime(rxData[1]-48,rxData[2]-48,
//                        rxData[4]-48,rxData[5]-48,
//                        rxData[7]-48,rxData[8]-48,rxData[9]-48);

                setTime(rxData[1]-48,rxData[2]-48,
                        rxData[4]-48,rxData[5]-48,
                        rxData[7]-48,rxData[8]-48,rxData[9]-48);
//System.out.println("Rx: it took [" + (char)rxData[1] + (char)rxData[2] + (char)rxData[3] + (char)rxData[4] + (char)rxData[5] + (char)rxData[6] + (char)rxData[7] + (char)rxData[8] + (char)rxData[8] + "] [min:sec.ms] to send string");
                txTask.ack();
              }

              else if (rxData[0] == 0x01 && rxCount == 1)
              {
//System.out.println("Rx: it took [" + (char)rxData[1] + (char)rxData[2] + (char)rxData[3] + (char)rxData[4] + (char)rxData[5] + (char)rxData[6] + (char)rxData[7] + (char)rxData[8] + (char)rxData[8] + "] [min:sec.ms] to send string");
                txTask.ack();
              }

              else if (rxData[0] == 0x02 && rxCount == 4)
              {
                incLostFrame((int)rxData[1], (int)rxData[2], (int)rxData[3]);
              }

              else
                System.out.print("Rx: received unknown frame (type: " + rxData[0] + ", length: " + rxCount + ")");

              rxState = 0;
            }
            else if (rxState == 3)
              rxState = 0;
          }

        }
        catch (IOException ioe) {
          closed = true;
        }
      }
    }
  } // end RxTask

  class TxTask implements Runnable {

    public void run() {
      byte[] data = null;
      while (true) {

        System.out.print("Tx: wait for data...");
        data = getData();
        System.out.println("done");

        try {

          if (!closed && data != null)
          {
            for (int i = 0; i < data.length; i++)
              sockOutput.write(data[i]);

/*
            for (int i = 0; i < data.length; i+=blockSize)
            {
              //Start frame
              sockOutput.write(DLE);
              sockOutput.write(STX);
              for (int j = 0; j < Math.min(blockSize, (data.length - i)); j++)
              {
                //put together frames...
                sockOutput.write(data[j+i]);
                if (data[j+i] == DLE)
                  sockOutput.write(DLE);
              }

              //Stop frame
              sockOutput.write(DLE);
              sockOutput.write(ETX);
*/
            System.out.print("Tx: wait for ack...");
            waitForAck();
            System.out.println("done");
//            }
          }
        }
        catch (IOException ioe) {
          System.out.println("TxTask.run(): "+ioe.getMessage());
        }
      }
    }

    public synchronized void waitForAck() {
      try {

        while (!acked)
          this.wait();

        acked = false;

      }
      catch (InterruptedException ie) {
        System.out.println("wait: "+ie.getMessage());
      }
    }

    public synchronized void ack()  {
      acked = true;
      notifyAll();
    }

    public synchronized void sendData(byte[] data)
    {
      byte[] messageToSend = new byte[9 + 2*data.length];
      int n = 0;

      //create frame to send...
      messageToSend[n++] = DLE;
      messageToSend[n++] = STX;

      messageToSend[n++] = 0x00;  //data frame

      messageToSend[n++] = new Integer(blockSize).byteValue();  //block size
      if (messageToSend[n-1] == DLE)
        messageToSend[n++] = DLE;

      messageToSend[n++] = 0x00;  //destination node
      if (messageToSend[n-1] == DLE)
        messageToSend[n++] = DLE;

      for (int i = 0; i < data.length; i++)
      {
        //put together frames...
        messageToSend[n++] = data[i];
        if (data[i] == DLE)
          messageToSend[n++] = DLE;
      }

      //Stop frame
      messageToSend[n++] = DLE;
      messageToSend[n++] = ETX;

      data2Send.add(messageToSend);
      notifyAll();
    }

    public synchronized void sendSync()
    {
      byte[] messageToSend = new byte[5];

      //create frame to send...
      messageToSend[0] = DLE;
      messageToSend[1] = STX;

      messageToSend[2] = 0x01;  //sync frame

      //Stop frame
      messageToSend[3] = DLE;
      messageToSend[4] = ETX;

      data2Send.add(messageToSend);
      notifyAll();
    }

    public synchronized void sendRaw(byte[] data)
    {
      data2Send.add(data);
      notifyAll();
    }

/*
    public synchronized void sendData(byte[] data)
    {
            for (int i = 0; i < data.length; i+=blockSize)
            {
              //Start frame
              sockOutput.write(DLE);
              sockOutput.write(STX);

              for (int j = 0; j < Math.min(blockSize, (data.length - i)); j++)
              {
                //put together frames...
                sockOutput.write(data[j+i]);
                if (data[j+i] == DLE)
                  sockOutput.write(DLE);
              }

              //Stop frame
              sockOutput.write(DLE);
              sockOutput.write(ETX);

      data2Send.add(data);
      notifyAll();
    }
*/

    public synchronized byte[] getData() {
      byte[] ret = null; 

      try {

        while (data2Send.size() == 0)
          wait();

        ret = (byte[]) data2Send.elementAt(0);
        data2Send.removeElementAt(0);

      }
      catch (InterruptedException ie) {
        System.out.println("getData: "+ie.getMessage());
      }

      return ret;

    }

    private boolean acked = false;
    private Vector data2Send = new Vector();
  } // End TxTask



  public static void main(String[] args) {
    if (args.length != 2) {
      System.out.println("Usage: java node 'port number' \"name\" ");
      return;
    }

    node m = new node(Integer.parseInt(args[0]),args[1]);
    
  }


  private JTextArea textArea;
  private JScrollPane textAreaScroll;
  private JTextField blSizeField;
  private JTextArea inputArea;
  private JLabel pktLbl;
  private JLabel timeLbl;
  private JLabel lostLbl;
  private int numPkt = 0;
  private int[] lostFrame = new int[3];

  private volatile boolean closed = true;

  private int serverPort = 1042;
  private int blockSize  = 20;
  private InputStream  sockInput;
  private OutputStream sockOutput;
  private ServerSocket server;

  private TxTask txTask;

  private byte DLE = 0x04;
  private byte STX = 0x02;
  private byte ETX = 0x03;
  private byte rxState = 0;
  private int  rxCount = 0;
  private byte[] rxData = new byte[1024];
  private byte[] timeArray = new byte[7];

  private final String PKT_STR = "Number of received frames: ";
  private final String TIME_STR = "Time to send [min:sec.ms]: ";
  private final String QUEUE_STR = "Lost frames in stub [0]/[1]/[2]: ";
}
