/*									tab:4
 *
 *
 * "Copyright (c) 2000-2002 The Regents of the University  of California.  
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice, the following
 * two paragraphs and the author appear in all copies of this software.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS."
 *
 */
/*									tab:4
 *  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.  By
 *  downloading, copying, installing or using the software you agree to
 *  this license.  If you do not agree to this license, do not download,
 *  install, copy or use the software.
 *
 *  Intel Open Source License 
 *
 *  Copyright (c) 2002 Intel Corporation 
 *  All rights reserved. 
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are
 *  met:
 * 
 *	Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *	Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *      Neither the name of the Intel Corporation nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 *  PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE INTEL OR ITS
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * 
 */
/*
 *
 * Authors:		Philip Levis (derived from work by Mike Castelle)
 * Date last modified:  6/25/02
 *
 */

/* 
 *   FILE: dbg_modes.h 
 * AUTHOR: Phil Levis (pal)
 *  DESCR: Definition of dbg modes and the bindings to DBG env settings. 
 */


#ifndef DBG_MODES_H
#define DBG_MODES_H

#define DBG_MODE(x)	(1ULL << (x))

enum {
  DBG_ALL =		(~0ULL),	/* umm, "verbose"		*/

/*====== Core mote modes =============*/
  DBG_BOOT =		DBG_MODE(0),	/* the boot sequence		*/
  DBG_CLOCK =		DBG_MODE(1),	/* clock        		*/
  DBG_TASK =		DBG_MODE(2),	/* task stuff			*/
  DBG_SCHED =		DBG_MODE(3),	/* switch, scheduling		*/
  DBG_SENSOR =		DBG_MODE(4),	/* sensor readings              */
  DBG_LED =	 	DBG_MODE(5),	/* LEDs         		*/
  DBG_QUEUE =	DBG_MODE(6),	/* queue      */

  /* basic */
  DBG_UART         = DBG_MODE(7),   /* uart commection tom simulated physical channel */
  DBG_FRAME        = DBG_MODE(8),   /* */
  DBG_FRAME_FSM    = DBG_MODE(9),   /* */
  DBG_CRC          = DBG_MODE(10),	  /* packet CRC stuff		*/
  DBG_STOPWAIT     = DBG_MODE(11),   /* */
  DBG_STOPWAIT_FSM = DBG_MODE(12),	/* */
  DBG_MAIN         = DBG_MODE(13),  /* */
  DBG_STRING       = DBG_MODE(14),	/* */
  DBG_NL           = DBG_MODE(15),	/* */
  DBG_QUEUE2       = DBG_MODE(16),  /* */
  DBG_MUX          = DBG_MODE(17),	/* */
  DBG_PING         = DBG_MODE(18),	/* */
  DBG_LINK         = DBG_MODE(19),	/* */
  DBG_LINK_T       = DBG_MODE(20),	/* */
  DBG_LEACKY       = DBG_MODE(21), /* */

  /* Future extensions */
  DBG_USR1         = DBG_MODE(22),	/* */
  DBG_USR2         = DBG_MODE(23),	/* */
  DBG_USR3         = DBG_MODE(24),	/* */
  DBG_USR4         = DBG_MODE(25),	/* */
  DBG_USR5         = DBG_MODE(26),	/* */
  DBG_USR6        =  DBG_MODE(27),	/* */
  DBG_USR7        =  DBG_MODE(28),	/* */
  DBG_USR8        =  DBG_MODE(29),	/* */
  DBG_SLIDING     =  DBG_MODE(30),	/* */

  DBG_ERROR       =  DBG_MODE(31),	/* Error condition		*/
  DBG_NONE        =  0,			        /* Nothing				*/
  DBG_DEFAULT     =  DBG_ALL       /* default modes, 0 for none	*/
};

#define DBG_NAMETAB \
  {"all",           DBG_ALL}, \
  {"boot",          DBG_BOOT|DBG_ERROR}, \
  {"clock",         DBG_CLOCK|DBG_ERROR}, \
  {"task",          DBG_TASK|DBG_ERROR}, \
  {"sched",         DBG_SCHED|DBG_ERROR}, \
  {"queue",         DBG_QUEUE|DBG_ERROR}, \
  {"uart",          DBG_UART|DBG_ERROR}, \
  {"frame",         DBG_FRAME|DBG_ERROR}, \
  {"frame_fsm",     DBG_FRAME_FSM|DBG_ERROR}, \
  {"crc",           DBG_CRC|DBG_ERROR}, \
  {"stopwait",      DBG_STOPWAIT|DBG_ERROR}, \
  {"stopwait_fsm",  DBG_STOPWAIT_FSM|DBG_ERROR}, \
  {"main",          DBG_MAIN|DBG_ERROR}, \
  {"string",        DBG_STRING|DBG_ERROR}, \
  {"nl",            DBG_NL|DBG_ERROR}, \
  {"queue2",        DBG_QUEUE2|DBG_ERROR}, \
  {"mux",           DBG_MUX|DBG_ERROR}, \
  {"ping",          DBG_PING|DBG_ERROR}, \
  {"link",          DBG_LINK|DBG_ERROR}, \
  {"link_t",        DBG_LINK_T|DBG_ERROR}, \
  {"leacky",        DBG_LEACKY|DBG_ERROR}, \
  {"usr1",          DBG_USR1|DBG_ERROR}, \
  {"usr2",          DBG_USR2|DBG_ERROR}, \
  {"usr3",          DBG_USR3|DBG_ERROR}, \
  {"usr4",          DBG_USR4|DBG_ERROR}, \
  {"usr5",          DBG_USR5|DBG_ERROR}, \
  {"usr6",          DBG_USR6|DBG_ERROR}, \
  {"usr7",          DBG_USR7|DBG_ERROR}, \
  {"usr8",          DBG_USR8|DBG_ERROR}, \
  {"sliding",       DBG_SLIDING|DBG_ERROR}, \
  {"error",         DBG_ERROR}, \
  {"none",          DBG_NONE}, \
  { NULL,           DBG_ERROR } 

//#define DBG_ENV		"DBG"

#endif 
