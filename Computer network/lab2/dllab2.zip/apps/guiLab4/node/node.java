import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

import java.util.Vector;

public class node extends JFrame implements ActionListener {

  public void actionPerformed(ActionEvent e) {
     if (e.getActionCommand().equals("Send")) {
       String outData = inputArea.getText();
       
       String blSize = blSizeField.getText();
       if(blSize != null && blSize.trim().length() > 0) {
         try {
           blockSize = Integer.parseInt(blSize);
         }catch(NumberFormatException bfe) {
         }
       }

       timeArray[0] = 0;
       timeArray[1] = 0;
       timeArray[2] = 0;
       timeArray[3] = 0;
       timeArray[4] = 0;
       timeArray[5] = 0;
       timeArray[6] = 0;
       timeLbl.setText(TIME_STR+" [00:00.000]");

       if(outData != null && outData.trim().length() > 0) {
         txTask.sendData(outData.getBytes());
       }
     }
     else if(e.getActionCommand().equals("Send 00-99"))
     {
       System.out.println("\nStarts sending 00-99...");

       //Parse block length...
       String blSize = blSizeField.getText();
       if(blSize != null && blSize.trim().length() > 0)
       {
         try
         {
           blockSize = Integer.parseInt(blSize);
           if (blockSize < 5)
             blockSize = 5;
           if (blockSize > 50)
             blockSize = 50;
         } catch(NumberFormatException bfe)
         {
         }
       }

       timeArray[0] = 0;
       timeArray[1] = 0;
       timeArray[2] = 0;
       timeArray[3] = 0;
       timeArray[4] = 0;
       timeArray[5] = 0;
       timeArray[6] = 0;
       timeLbl.setText(TIME_STR+" [00:00.000]");

       //Add all packats to send to output buffer...
       int j;
       
       for (int i = 0; i < 100; i++)
       {
         byte[] txData = new byte[blockSize];

         txData[0] = (byte)('0' + i / 10);
         txData[1] = (byte)('0' + i % 10);
         txData[2] = (byte)' ';
         for(j = 3; j < blockSize-1; j++)
           txData[j] = (byte)('a' + j - 3);
         txData[j] = (byte)'\n';

         txTask.sendData(txData);
       }
     }
     else if(e.getActionCommand().equals("Reset")) {
       numPkt = 0;
       pktLbl.setText(PKT_STR+"     "+numPkt+"   ");
       timeArray[0] = 0;
       timeArray[1] = 0;
       timeArray[2] = 0;
       timeArray[3] = 0;
       timeArray[4] = 0;
       timeArray[5] = 0;
       timeArray[6] = 0;
       timeLbl.setText(TIME_STR+" [00:00.000]");
       textArea.setText("");
       txTask.sendSync();
     }
  }


  public node(int port, String name) {

    this.serverPort = port;


    JPanel back = new JPanel(new BorderLayout());

    // --- west side - text area ---
    JPanel textAreaPnl = new JPanel();
    textArea = new JTextArea(10, 22);
    textAreaScroll = new JScrollPane(textArea);
    textAreaScroll.setAutoscrolls(true);

    textAreaPnl.add(textAreaScroll);

    back.add(textAreaPnl, BorderLayout.CENTER);

    // --- east side ---
    JPanel east = new JPanel(new BorderLayout());

    // block size
    JPanel blSizePnl = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JLabel blSizeLbl = new JLabel("Block size (5-50): ");
    blSizeField      = new JTextField(5); 
    blSizeField.setText(""+blockSize);

    blSizePnl.add(blSizeLbl);
    blSizePnl.add(blSizeField);

    east.add(blSizePnl, BorderLayout.NORTH);

    // input area
    JPanel inpPnl = new JPanel();
    JPanel inputAreaPnl = new JPanel(new BorderLayout());

    inputArea = new JTextArea(3,20);
    inputArea.setLineWrap(true);
    inpPnl.add(new JScrollPane(inputArea));
    inputAreaPnl.add(inpPnl, BorderLayout.CENTER);

    east.add(inputAreaPnl, BorderLayout.CENTER);

    // send buttons
    JPanel sendBtnPnl = new JPanel();
    JButton sendBtn = new JButton("Send");
    sendBtn.addActionListener(this);
    sendBtnPnl.add(sendBtn);
    
    JButton send999Btn = new JButton("Send 00-99");
    send999Btn.addActionListener(this);
    sendBtnPnl.add(send999Btn);

    inputAreaPnl.add(sendBtnPnl, BorderLayout.SOUTH);


    // info
    JPanel infoPnl = new JPanel(new BorderLayout());
    pktLbl  = new JLabel(PKT_STR+"     0   ");
    JButton resetBtn = new JButton("Reset");
    resetBtn.addActionListener(this);

    infoPnl.add(pktLbl,BorderLayout.WEST);
    infoPnl.add(resetBtn,BorderLayout.EAST);
    timeLbl  = new JLabel(TIME_STR+" [00:00.000]");
    infoPnl.add(timeLbl,BorderLayout.SOUTH);

    east.add(infoPnl, BorderLayout.SOUTH);

    back.add(east, BorderLayout.EAST);

    timeArray[0] = 0;
    timeArray[1] = 0;
    timeArray[2] = 0;
    timeArray[3] = 0;
    timeArray[4] = 0;
    timeArray[5] = 0;
    timeArray[6] = 0;

    this.getContentPane().add(back);
    this.setTitle(name);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//    this.setSize(525, 225);
    this.pack();
    this.setVisible(true);


    // start threads
    new Thread(new RxTask()).start();
    txTask = new TxTask();
    new Thread(txTask).start();
  }

  private void incNumPkt(int num) {
    numPkt+=num;
    pktLbl.setText(PKT_STR+numPkt+"   ");
  }

  private void incTime(int n1, int n2, int n3, int n4, int n5, int n6, int n7) {
    timeArray[6] += n7;
    if (timeArray[6] >= 10)
    {
      timeArray[6] -= 10;
      timeArray[5]++;
    }
    timeArray[5] += n6;
    if (timeArray[5] >= 10)
    {
      timeArray[5] -= 10;
      timeArray[4]++;
    }
    timeArray[4] += n5;
    if (timeArray[4] >= 10)
    {
      timeArray[4] -= 10;
      timeArray[3]++;
    }
    timeArray[3] += n4;
    if (timeArray[3] >= 10)
    {
      timeArray[3] -= 10;
      timeArray[2]++;
    }
    timeArray[2] += n3;
    if (timeArray[2] >= 6)
    {
      timeArray[2] -= 6;
      timeArray[1]++;
    }
    timeArray[1] += n2;
    if (timeArray[1] >= 10)
    {
      timeArray[1] -= 10;
      timeArray[0]++;
    }
    timeArray[0] += n1;
    if (timeArray[0] >= 10)
      timeArray[0] -= 10;

//System.out.println("[" + timeArray[0] + timeArray[1] + timeArray[2] + timeArray[3] + timeArray[4] + timeArray[5] + timeArray[6] + "]");
       
    timeLbl.setText(TIME_STR+"["+timeArray[0]+timeArray[1]+":"+timeArray[2]+timeArray[3]+"."+timeArray[4]+timeArray[5]+timeArray[6]+"]");
  }



  class RxTask implements Runnable {

    public void run() {
      int ch;

      try {
        server = new ServerSocket(serverPort);
      }
      catch (IOException ie) {
        System.out.println("RxTask.run(): "+ie.getMessage());
        return;
      }

      while (true) {
        try {

          // wait for a connection
          Socket sock = server.accept();

          // get streams from socket
          sockInput  = sock.getInputStream();
          sockOutput = sock.getOutputStream();

          closed = false;

          // read data from socket and forward to other end
          while (!closed) {
            ch = sockInput.read();

            //Check if connection is broken...
            if (ch == -1)
              throw new IOException();

            //State machine to decrypt frames...
            if (rxState == 0 && (byte)ch == DLE)
              rxState = 1;

            else if (rxState == 1 && (byte)ch == STX)
            {
              rxCount = 0;    //reset buffer
//              System.out.print("Rx: reset buffer...");
              rxState = 2;
            }
            else if (rxState == 1 && (byte)ch == DLE)
              rxState = 1;
            else if (rxState == 1)
              rxState = 0;

            else if (rxState == 2 && (byte)ch == DLE)
              rxState = 3;
            else if (rxState == 2)
            {
              //add to buffer
//              System.out.print("Rx: add["+ ch +"] to buffer...");
              rxData[rxCount] = (byte)ch;
              rxCount++;
            }

            else if (rxState == 3 && (byte)ch == DLE)
            {
              //add to buffer
//              System.out.print("Rx: add["+ ch +"] to buffer...");
              rxData[rxCount] = (byte)ch;
              rxCount++;
            }
            else if (rxState == 3 && (byte)ch == STX)
            {
              rxCount = 0;  //reset buffer
//              System.out.print("Rx: reset buffer...");
              rxState = 2;
            }
            else if (rxState == 3 && (byte)ch == ETX)
            {
              //evaluate buffer
//              System.out.print("Rx: evaluate buffer (len: " + rxData.length + ", " + rxCount + " ), [0]= " + rxData[0] + ";");

              //check if data frame
              if (rxData[0] == 0x00)
              {
                incNumPkt(1);
                for (int i = 1; i < rxCount; i++)
                  textArea.append(""+(char)rxData[i]);
              }

              //check if ack frame
              else if (rxData[0] == 0x01 && rxCount == 10)
              {
                incTime(rxData[1]-48,rxData[2]-48,
                        rxData[4]-48,rxData[5]-48,
                        rxData[7]-48,rxData[8]-48,rxData[9]-48);
//System.out.println("Rx: it took [" + (char)rxData[1] + (char)rxData[2] + (char)rxData[3] + (char)rxData[4] + (char)rxData[5] + (char)rxData[6] + (char)rxData[7] + (char)rxData[8] + (char)rxData[8] + "] [min:sec.ms] to send string");
                txTask.ack();
              }

              else if (rxData[0] == 0x01 && rxCount == 1)
              {
//System.out.println("Rx: it took [" + (char)rxData[1] + (char)rxData[2] + (char)rxData[3] + (char)rxData[4] + (char)rxData[5] + (char)rxData[6] + (char)rxData[7] + (char)rxData[8] + (char)rxData[8] + "] [min:sec.ms] to send string");
                txTask.ack();
              }

              else
                System.out.print("Rx: received unknown frame (type: " + rxData[0] + ", length: " + rxCount + ")");

              rxState = 0;
            }
            else if (rxState == 3)
              rxState = 0;
          }

        }
        catch (IOException ioe) {
          closed = true;
        }
      }
    }
  } // end RxTask

  class TxTask implements Runnable {

    public void run() {
      byte[] data = null;
      while (true) {

        System.out.print("Tx: wait for data...");
        data = getData();
        System.out.println("done");

        try {

          if (!closed && data != null)
          {
            for (int i = 0; i < data.length; i++)
              sockOutput.write(data[i]);

/*
            for (int i = 0; i < data.length; i+=blockSize)
            {
              //Start frame
              sockOutput.write(DLE);
              sockOutput.write(STX);
              for (int j = 0; j < Math.min(blockSize, (data.length - i)); j++)
              {
                //put together frames...
                sockOutput.write(data[j+i]);
                if (data[j+i] == DLE)
                  sockOutput.write(DLE);
              }

              //Stop frame
              sockOutput.write(DLE);
              sockOutput.write(ETX);
*/
            System.out.print("Tx: wait for ack...");
            waitForAck();
            System.out.println("done");
//            }
          }
        }
        catch (IOException ioe) {
          System.out.println("TxTask.run(): "+ioe.getMessage());
        }
      }
    }

    public synchronized void waitForAck() {
      try {

        while (!acked)
          this.wait();

        acked = false;

      }
      catch (InterruptedException ie) {
        System.out.println("wait: "+ie.getMessage());
      }
    }

    public synchronized void ack()  {
      acked = true;
      notifyAll();
    }

    public synchronized void sendData(byte[] data)
    {
      for (int i = 0; i < data.length; i+=blockSize)
      {
        byte[] messageToSend = new byte[4 + 2*blockSize];
        int n = 0;

        //create frame to send...
        messageToSend[n++] = DLE;
        messageToSend[n++] = STX;

        messageToSend[n++] = 0x00;  //data frame

        for (int j = 0; j < Math.min(blockSize, (data.length - i)); j++)
        {
          //put together frames...
          messageToSend[n++] = data[j+i];
          if (data[j+i] == DLE)
            messageToSend[n++] = DLE;
        }

        //Stop frame
        messageToSend[n++] = DLE;
        messageToSend[n++] = ETX;

        data2Send.add(messageToSend);
        notifyAll();
      }
    }

    public synchronized void sendSync()
    {
      byte[] messageToSend = new byte[5];

      //create frame to send...
      messageToSend[0] = DLE;
      messageToSend[1] = STX;

      messageToSend[2] = 0x01;  //sync frame

      //Stop frame
      messageToSend[3] = DLE;
      messageToSend[4] = ETX;

      data2Send.add(messageToSend);
      notifyAll();
    }

    public synchronized void sendRaw(byte[] data)
    {
      data2Send.add(data);
      notifyAll();
    }

/*
    public synchronized void sendData(byte[] data)
    {
            for (int i = 0; i < data.length; i+=blockSize)
            {
              //Start frame
              sockOutput.write(DLE);
              sockOutput.write(STX);

              for (int j = 0; j < Math.min(blockSize, (data.length - i)); j++)
              {
                //put together frames...
                sockOutput.write(data[j+i]);
                if (data[j+i] == DLE)
                  sockOutput.write(DLE);
              }

              //Stop frame
              sockOutput.write(DLE);
              sockOutput.write(ETX);

      data2Send.add(data);
      notifyAll();
    }
*/

    public synchronized byte[] getData() {
      byte[] ret = null; 

      try {

        while (data2Send.size() == 0)
          wait();

        ret = (byte[]) data2Send.elementAt(0);
        data2Send.removeElementAt(0);

      }
      catch (InterruptedException ie) {
        System.out.println("getData: "+ie.getMessage());
      }

      return ret;

    }

    private boolean acked = false;
    private Vector data2Send = new Vector();
  } // End TxTask



  public static void main(String[] args) {
    if (args.length != 2) {
      System.out.println("Usage: java Monitor 'port number' \"name\" ");
      return;
    }

    node m = new node(Integer.parseInt(args[0]),args[1]);
    
  }


  private JTextArea textArea;
  private JScrollPane textAreaScroll;
  private JTextField blSizeField;
  private JTextArea inputArea;
  private JLabel pktLbl;
  private JLabel timeLbl;
  private int numPkt = 0;

  private volatile boolean closed = true;

  private int serverPort = 1042;
  private int blockSize  = 20;
  private InputStream  sockInput;
  private OutputStream sockOutput;
  private ServerSocket server;

  private TxTask txTask;

  private byte DLE = 0x04;
  private byte STX = 0x02;
  private byte ETX = 0x03;
  private byte rxState = 0;
  private int  rxCount = 0;
  private byte[] rxData = new byte[1024];
  private byte[] timeArray = new byte[7];

  private final String PKT_STR = "Number of received strings: ";
  private final String TIME_STR = "Time to send [min:sec.ms]: ";
}
